from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='login'),
    path('home/', views.home, name='home'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),

    # 👇 Add these
    path('attendance/', views.attendance_view, name='attendance'),
    path('feedback/', views.feedback_view, name='feedback'),
    path('students/', views.student_list, name='students'),
]