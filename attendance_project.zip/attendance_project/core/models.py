from django.db import models
from django.contrib.auth.models import AbstractUser
from django.conf import settings


# 🔐 Custom User Model with Role
class CustomUser(AbstractUser):
    ROLE_CHOICES = [
        ('student', 'Student'),
        ('teacher', 'Teacher'),
        ('admin', 'Admin'),
    ]

    role = models.CharField(
        max_length=50,
        choices=ROLE_CHOICES,
        blank=True,
        null=True
    )

    def __str__(self):
        return f"{self.username} ({self.role})"


# 🎓 Student Profile
class Student(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="student_profile",
        null=True,
        blank=True
    )
    roll_no = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=100)
    course = models.CharField(max_length=100)
    year = models.CharField(max_length=10)
    email = models.EmailField(unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} ({self.roll_no})"

    # 📊 Attendance percentage calculation
    def attendance_percentage(self):
        total = self.attendance_records.count()
        present = self.attendance_records.filter(status='Present').count()
        return round((present / total) * 100, 1) if total > 0 else 0


# 🗓️ Attendance Model
class Attendance(models.Model):
    STATUS_CHOICES = [
        ('Present', 'Present'),
        ('Absent', 'Absent'),
        ('Late', 'Late'),
        ('Leave', 'Leave'),
    ]

    student = models.ForeignKey(
        'Student',  # use string reference to avoid circular import
        on_delete=models.CASCADE,
        related_name="attendance_records"
    )
    # ❌ FIXED: allow manual date entry
    date = models.DateField()  
    course = models.CharField(max_length=100)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES)
    remarks = models.TextField(blank=True, null=True)

    marked_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="attendance_marked"
    )
    marked_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date']
        unique_together = ('student', 'date')
        verbose_name = "Attendance Record"
        verbose_name_plural = "Attendance Records"

    def __str__(self):
        return f"{self.student.name} - {self.date.strftime('%d %b %Y')} ({self.status})"

    def short_status(self):
        return self.status.lower()

# 💬 Feedback Model
class Feedback(models.Model):
    student = models.ForeignKey(
        Student,
        on_delete=models.CASCADE,
        related_name="feedbacks"
    )
    subject = models.CharField(max_length=100, blank=True, null=True)
    rating = models.IntegerField(
        choices=[(1,'⭐'),(2,'⭐⭐'),(3,'⭐⭐⭐'),(4,'⭐⭐⭐⭐'),(5,'⭐⭐⭐⭐⭐')]
    )
    comments = models.TextField(blank=True, null=True)
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.student.name} - {self.rating}⭐"