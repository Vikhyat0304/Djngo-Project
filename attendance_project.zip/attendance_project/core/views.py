from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db.models import Avg, Count
from django.contrib.auth import get_user_model
from django.utils import timezone
from django.http import JsonResponse

from .models import Student, Attendance, Feedback
from .forms import AttendanceForm, FeedbackForm, RegisterForm, LoginForm

User = get_user_model()


# 🏠 Home Page (Accessible only when logged in)
@login_required(login_url='login')
def home(request):
    return render(request, 'core/home.html')


# 🧾 Register View (For Student / Teacher)
def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')  # Already logged in → go to dashboard

    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.role = form.cleaned_data.get('role')
            user.save()
            login(request, user)
            messages.success(request, f'Account created successfully as {user.role.capitalize()}!')
            return redirect('dashboard')
        else:
            messages.error(request, 'Please correct the highlighted errors below.')
    else:
        form = RegisterForm()

    return render(request, 'core/register.html', {'form': form})


# 🔐 Login View
def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')  # Prevent showing login page to logged-in users

    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                messages.success(request, f'Welcome back, {user.first_name or user.username}!')
                return redirect('home')
            else:
                messages.error(request, 'Invalid username or password.')
        else:
            messages.error(request, 'Invalid login details. Please try again.')
    else:
        form = LoginForm()

    return render(request, 'core/login.html', {'form': form})


# 🚪 Logout View
@login_required(login_url='login')
def logout_view(request):
    logout(request)
    messages.info(request, 'You have been logged out successfully.')
    return redirect('login')


# 🧑‍🎓 Student List (Teacher Only)
@login_required
def student_list(request):
    if not hasattr(request.user, 'role') or request.user.role != 'teacher':
        messages.warning(request, 'Access Denied: Teachers only.')
        return redirect('dashboard')

    students = Student.objects.all().order_by('roll_no')
    return render(request, 'core/students_list.html', {'students': students})


# 🗓️ Mark Attendance (Teacher Only)
@login_required
def attendance_view(request):
    students = Student.objects.all()

    if request.method == 'POST' and request.headers.get('x-requested-with') == 'XMLHttpRequest':
        student_id = request.POST.get('student_id')
        status = request.POST.get('status')

        try:
            student = Student.objects.get(id=student_id)
            Attendance.objects.update_or_create(
                student=student,
                date=timezone.now().date(),
                defaults={
                    'status': status,
                    'course': student.course,
                    'marked_by': request.user
                }
            )
            return JsonResponse({'success': True, 'message': f'{student.name} marked {status}'})
        except Student.DoesNotExist:
            return JsonResponse({'success': False, 'message': 'Student not found'})

    return render(request, 'core/attendance.html', {'students': students})


# 💬 Submit Feedback (Student Only)
@login_required
def feedback_view(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            feedback = form.save(commit=False)
            # 🔥 Auto attach logged-in student's record
            feedback.student = Student.objects.get(user=request.user)
            feedback.save()
            messages.success(request, '✅ Thank you! Your feedback has been submitted successfully.')
            return redirect('feedback')
        else:
            messages.error(request, '❌ Please correct the errors below.')
    else:
        form = FeedbackForm()

    return render(request, 'core/feedback.html', {'form': form})



# 📊 Dashboard (for both Teacher & Student)
@login_required
def dashboard(request):
    all_attendance = Attendance.objects.select_related('student').all()

    # Aggregate attendance data per student
    students_data = []
    for student in Student.objects.all():
        total = all_attendance.filter(student=student).count()
        present = all_attendance.filter(student=student, status='Present').count()
        absent = total - present
        attendance_pct = round((present / total) * 100, 1) if total > 0 else 0

        students_data.append({
            'name': student.name,
            'roll_no': student.roll_no,
            'course': student.course,
            'attendance_pct': attendance_pct,
        })

    # Overall stats
    total_sessions = all_attendance.count()
    present_count = all_attendance.filter(status='Present').count()
    overall_attendance_pct = round((present_count / total_sessions) * 100, 1) if total_sessions > 0 else 0

    # Feedback stats
    feedbacks = Feedback.objects.all()
    avg_rating = round(feedbacks.aggregate(Avg('rating'))['rating__avg'] or 0, 1)
    rating_distribution = feedbacks.values('rating').annotate(count=Count('rating')).order_by('rating')

    rating_labels = [str(f['rating']) for f in rating_distribution]
    rating_counts = [f['count'] for f in rating_distribution]

    # Student chart data
    student_labels = [s['name'] for s in students_data]
    attendance_values = [s['attendance_pct'] for s in students_data]

    context = {
        'students_data': students_data,
        'overall_attendance_pct': overall_attendance_pct,
        'overall_total_sessions': total_sessions,
        'avg_rating': avg_rating,
        'student_labels': student_labels,
        'attendance_values': attendance_values,
        'rating_labels': rating_labels,
        'rating_counts': rating_counts,
    }

    return render(request, 'core/dashboard.html', context)


# 💭 Feedback View (General)

@login_required
def feedback_view(request):
    # Ensure logged-in user has a Student profile — create a minimal one if not present
    student_profile = getattr(request.user, 'student_profile', None)
    if student_profile is None:
        # create a minimal Student record using user info (adjust fields as needed)
        student_profile, created = Student.objects.get_or_create(
            user=request.user,
            defaults={
                'name': f"{request.user.first_name or request.user.username}",
                'roll_no': f"R{request.user.id}",
                'course': 'N/A',
                'year': 'N/A',
                'email': request.user.email or f'{request.user.username}@example.com',
            }
        )

    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            feedback = form.save(commit=False)
            feedback.student = student_profile   # assign logged-in student
            feedback.save()
            messages.success(request, "✅ Thank you — feedback submitted.")
            return redirect('feedback')  # or wherever you want to go
        else:
            messages.error(request, "❌ Please correct the errors below.")
    else:
        form = FeedbackForm()

    return render(request, 'core/feedback.html', {'form': form})