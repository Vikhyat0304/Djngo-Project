from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import get_user_model
from .models import Attendance, Feedback, Student

# Get the custom user model
User = get_user_model()


# ===========================
# 🔐 USER REGISTRATION FORM
# ===========================
class RegisterForm(UserCreationForm):
    ROLE_CHOICES = [
        ('student', 'Student'),
        ('teacher', 'Teacher'),
    ]

    role = forms.ChoiceField(
        choices=ROLE_CHOICES,
        widget=forms.Select(attrs={'class': 'form-select'})
    )

    first_name = forms.CharField(
        max_length=30,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter First Name'
        })
    )

    last_name = forms.CharField(
        max_length=30,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter Last Name'
        })
    )

    username = forms.CharField(
        max_length=30,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Choose Username'
        })
    )

    email = forms.EmailField(
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter Email'
        })
    )

    password1 = forms.CharField(
        label='Password',
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Create Password'
        })
    )

    password2 = forms.CharField(
        label='Confirm Password',
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Confirm Password'
        })
    )

    class Meta:
        model = User
        fields = [
            'first_name',
            'last_name',
            'username',
            'email',
            'role',
            'password1',
            'password2',
        ]


# ===========================
# 🔑 USER LOGIN FORM
# ===========================
class LoginForm(AuthenticationForm):
    username = forms.CharField(
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter Username'
        })
    )

    password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter Password'
        })
    )


# ===========================
# 🗓️ ATTENDANCE FORM
# ===========================
class AttendanceForm(forms.ModelForm):
    student = forms.ModelChoiceField(
        queryset=Student.objects.all().order_by('name'),
        widget=forms.Select(attrs={
            'class': 'form-select shadow-sm',
            'style': 'border-radius:10px;',
        }),
        label="👨‍🎓 Select Student"
    )

    date = forms.DateField(
        widget=forms.DateInput(attrs={
            'class': 'form-control shadow-sm',
            'type': 'date',
            'style': 'border-radius:10px;',
        }),
        label="📅 Attendance Date"
    )

    course = forms.CharField(
        widget=forms.TextInput(attrs={
            'class': 'form-control shadow-sm',
            'placeholder': 'Enter Course Name',
            'style': 'border-radius:10px;',
        }),
        label="📘 Course Name"
    )

    status = forms.ChoiceField(
        choices=Attendance.STATUS_CHOICES,
        widget=forms.Select(attrs={
            'class': 'form-select shadow-sm',
            'style': 'border-radius:10px;',
        }),
        label="🟢 Attendance Status"
    )

    remarks = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={
            'class': 'form-control shadow-sm',
            'rows': 2,
            'placeholder': 'Add any remarks (optional)...',
            'style': 'border-radius:10px;',
        }),
        label="💬 Remarks"
    )

    class Meta:
        model = Attendance
        fields = ['student', 'course', 'date', 'status', 'remarks']

# ===========================
# 💬 FEEDBACK FORM
# ===========================
class FeedbackForm(forms.ModelForm):
    class Meta:
        model = Feedback
        # NOTE: do NOT include 'student' here
        fields = ['subject', 'rating', 'comments']
        widgets = {
            'subject': forms.TextInput(attrs={'class':'form-control','placeholder':'Subject (optional)'}),
            'rating': forms.Select(attrs={'class':'form-select'}, choices=[
                (1,'⭐'),(2,'⭐⭐'),(3,'⭐⭐⭐'),(4,'⭐⭐⭐⭐'),(5,'⭐⭐⭐⭐⭐')
            ]),
            'comments': forms.Textarea(attrs={'class':'form-control','rows':3,'placeholder':'Write feedback...'}),
        }